﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SmartRenamer.Converters
{
    /// <summary>
    /// Returns Visible when the string contains text.
    /// Otherwise Collapsed.
    /// </summary>
    public class StringToVisibilityConverter : IValueConverter
    {
        public object Convert(
            object value,
            Type targetType,
            object parameter,
            CultureInfo culture)
        {
            if (value is string text &&
                !string.IsNullOrWhiteSpace(text))
            {
                return Visibility.Visible;
            }

            return Visibility.Collapsed;
        }

        public object ConvertBack(
            object value,
            Type targetType,
            object parameter,
            CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}