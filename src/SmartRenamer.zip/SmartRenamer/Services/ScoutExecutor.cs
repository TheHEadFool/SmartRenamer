﻿using System;
using System.Collections.Generic;
using System.IO;
using SmartRenamer.Models.Rename;

namespace SmartRenamer.Services
{
    /// <summary>
    /// Executes an approved Scout organization plan.
    /// Copies files into a new organized folder structure,
    /// leaving the originals untouched.
    /// </summary>
    public class ScoutExecutor
    {
        public RenameResult Execute(List<RenamePreview> preview)
        {
            RenameResult result = new();

            if (preview == null || preview.Count == 0)
            {
                result.Errors.Add("Nothing to organize.");
                return result;
            }

            // Determine the source folder from the first file.
            string sourceFolder =
                Path.GetDirectoryName(preview[0].FullPath)!;

            string scoutFolder =
                sourceFolder + " (Scout Organized)";

            Directory.CreateDirectory(scoutFolder);

            result.Success = true;

            return result;
        }
    }
}