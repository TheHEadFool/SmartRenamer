﻿# SmartRenamer Vision

SmartRenamer should feel like working alongside a trusted friend who is exceptionally good at organizing digital information—and who enjoys helping you become just as good.

Scout should understand the user's goal before suggesting actions.

SmartRenamer is not simply a file renaming application.

It is a collaborative workspace for organizing digital information.

The Guide works alongside the user, asking meaningful questions, explaining recommendations, and helping build workflows that accomplish real projects.

Our goal is not simply to automate organization.

Our goal is to help people become more confident and capable organizers of their digital world.

## Core Principles

Projects before files.

Guide before wizard.

Teach outcomes, not features.

Explain recommendations.

Preview before changing.

Undo everything.

Build confidence.

Technology should disappear behind conversation.

Community knowledge is as valuable as built-in features.

Plugins should feel native.

Support files wherever they live.

The user always remains in control.

The Guide never asks users to make technical decisions. It asks questions they can confidently answer, explains why the answers matter, and translates those answers into technical solutions

Progressive Disclosure

The Guide should reveal only what the user needs right now.

Not all options.

Not all settings.

Not every technology.

Just the next useful thing.

That's exactly how a good mentor teaches.

- The Guide observes before advising.
- The Guide asks only questions whose answers it cannot discover.
- Friend should never need to learn technical terminology.
- Every action should be reversible.
- The conversation is the primary interface.
- Software should teach while it works.

## Identity

The application is evolving from a file renaming utility into an intelligent file organization assistant.

Its primary value is understanding a project before suggesting actions.

Capabilities represent things Friend knows how to do. Users may assemble them manually, but the long-term goal is for Friend to automatically select and arrange the necessary capabilities based on the user's intent.

Scout remembers successful workflows so Friend never has to repeat themselves