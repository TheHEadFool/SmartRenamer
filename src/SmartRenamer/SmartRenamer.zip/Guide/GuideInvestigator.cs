﻿using System.Text;
using SmartRenamer.Models;
using SmartRenamer.Services;

namespace SmartRenamer.Guide
{
    /// <summary>
    /// Helps the Guide understand a project by asking the
    /// ProjectInvestigator to examine it and then translating
    /// the results into conversational language.
    /// </summary>
    public class GuideInvestigator
    {
        private readonly ProjectInvestigator projectInvestigator = new();

        private readonly ProjectAnalyzer projectAnalyzer = new();

        /// <summary>
        /// Investigates a project selected by the user.
        /// </summary>
        public ProjectContext? Investigate()
        {
            ProjectContext? context = projectInvestigator.Investigate();

            if (context != null)
            {
                projectAnalyzer.Analyze(context);
            }

            return context;
        }

        /// <summary>
        /// Converts technical project information into
        /// conversational language.
        /// </summary>
        public string Summarize(ProjectContext context)
        {
            if (context == null || context.Folder == null)
            {
                return "I wasn't able to investigate the project.";
            }

            StringBuilder summary = new();

            summary.AppendLine($"I think this is a **{context.ProjectType}** project.");
            summary.AppendLine($"Confidence: {context.Confidence}%");
            summary.AppendLine();

            summary.AppendLine("Here's what I noticed:");

            foreach (ProjectObservation observation in context.Observations)
            {
                summary.AppendLine($"• {observation.Description}");
            }

            if (context.RecommendedCapabilities.Count > 0)
            {
                summary.AppendLine();
                summary.AppendLine("I recommend these capabilities:");

                foreach (string capability in context.RecommendedCapabilities)
                {
                    summary.AppendLine($"✓ {capability}");
                }
            }

            return summary.ToString();
        }
    }
}