﻿namespace SmartRenamer.Models.Analysis
{
    public class Recommendation
    {
        public string Title { get; set; } = "";

        public string Description { get; set; } = "";

        public int Priority { get; set; }
    }
}