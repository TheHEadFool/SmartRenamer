﻿using SmartRenamer.Services;
using System.Collections.Generic;

namespace SmartRenamer.Models
{
    public class ProjectContext
    {
        public FolderSummary? Folder { get; set; }

        public string ProjectGoal { get; set; } = "";

        public bool KeepOriginals { get; set; } = true;

        public string ProjectType { get; set; } = "Unknown";

        public int Confidence { get; set; }

        public List<ProjectObservation> Observations { get; }
            = new();

        public List<string> RecommendedCapabilities { get; }
            = new();
    }
}