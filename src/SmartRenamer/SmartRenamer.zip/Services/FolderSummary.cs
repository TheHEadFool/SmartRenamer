﻿using System.Collections.Generic;

namespace SmartRenamer.Services
{
    public class FolderSummary
    {
        public string FolderPath { get; set; } = "";

        public int FolderCount { get; set; }

        public int FileCount { get; set; }

        public int ImageCount { get; set; }

        public int VideoCount { get; set; }

        public int DocumentCount { get; set; }

        public long TotalBytes { get; set; }

        public string OldestFileDate { get; set; } = "";

        public string NewestFileDate { get; set; } = "";

        // File types discovered

        public List<string> Extensions { get; } = new();

        // Project characteristics

        public bool HasRawPhotos { get; set; }

        public bool HasExifImages { get; set; }

        public bool HasVideos { get; set; }

        public bool HasSubfolders { get; set; }
    }
}