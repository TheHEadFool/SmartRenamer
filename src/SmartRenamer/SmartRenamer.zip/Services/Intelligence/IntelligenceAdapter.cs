﻿using SmartRenamer.Models;
using SmartRenamer.Models.Analysis;

namespace SmartRenamer.Services.Intelligence
{
    /// <summary>
    /// Bridges the new Project Intelligence Engine with the
    /// existing ProjectContext so the rest of the application
    /// can continue working while we migrate to the new
    /// architecture.
    /// </summary>
    public class IntelligenceAdapter
    {
        private readonly ProjectIntelligenceEngine engine = new();

        /// <summary>
        /// Runs the Intelligence Engine and copies its
        /// results into the existing ProjectContext.
        /// </summary>
        public void Analyze(ProjectContext context)
        {
            if (context == null)
                return;

            AnalysisResult result = engine.Analyze(context);

            if (result == null)
                return;

            ProjectProfile profile = result.Profile;

            if (profile == null)
                return;

            context.ProjectType = profile.ProjectType;
            context.Confidence = profile.Confidence;

            context.Observations.Clear();

            context.Observations.Add(new ProjectObservation
            {
                Description =
                    $"Detected project type: {profile.ProjectType}"
            });

            context.Observations.Add(new ProjectObservation
            {
                Description =
                    $"Confidence: {profile.Confidence}%"
            });

            context.RecommendedCapabilities.Clear();

            foreach (Recommendation recommendation in profile.Recommendations)
            {
                context.RecommendedCapabilities.Add(
                    recommendation.Title);
            }
        }
    }
}