﻿using SmartRenamer.Models;

namespace SmartRenamer.Services
{
    /// <summary>
    /// Looks at a project and decides which capabilities
    /// would be most useful.
    /// </summary>
    public class ProjectAnalyzer
    {
        public void Analyze(ProjectContext context)
        {
            if (context == null || context.Folder == null)
                return;

            FolderSummary folder = context.Folder;

            //--------------------------------------------------
            // Determine project type
            //--------------------------------------------------

            if (folder.ImageCount > folder.VideoCount &&
                folder.ImageCount > folder.DocumentCount)
            {
                context.ProjectType = "Photography";
                context.Confidence = 90;
            }
            else if (folder.VideoCount > folder.DocumentCount)
            {
                context.ProjectType = "Video";
                context.Confidence = 85;
            }
            else if (folder.DocumentCount > 0)
            {
                context.ProjectType = "Documents";
                context.Confidence = 80;
            }
            else
            {
                context.ProjectType = "Mixed Files";
                context.Confidence = 50;
            }

            //--------------------------------------------------
            // Observations
            //--------------------------------------------------

            context.Observations.Clear();

            if (folder.ImageCount > 0)
            {
                context.Observations.Add(new ProjectObservation
                {
                    Title = "Images",
                    Description = $"The project contains {folder.ImageCount:N0} image files.",
                    Severity = ObservationSeverity.Information
                });
            }

            if (folder.VideoCount > 0)
            {
                context.Observations.Add(new ProjectObservation
                {
                    Title = "Videos",
                    Description = $"The project contains {folder.VideoCount:N0} video files.",
                    Severity = ObservationSeverity.Information
                });
            }

            if (folder.DocumentCount > 0)
            {
                context.Observations.Add(new ProjectObservation
                {
                    Title = "Documents",
                    Description = $"The project contains {folder.DocumentCount:N0} document files.",
                    Severity = ObservationSeverity.Information
                });
            }

            if (folder.FileCount > 500)
            {
                context.Observations.Add(new ProjectObservation
                {
                    Title = "Large Project",
                    Description = $"This project contains {folder.FileCount:N0} files.",
                    Severity = ObservationSeverity.Suggestion
                });
            }

            //--------------------------------------------------
            // Recommended capabilities
            //--------------------------------------------------

            context.RecommendedCapabilities.Clear();

            if (folder.ImageCount > 0)
            {
                context.RecommendedCapabilities.Add(
                    CapabilityNames.ReadExif);
            }

            if (folder.VideoCount > 0)
            {
                context.RecommendedCapabilities.Add(
                    CapabilityNames.ReadVideoMetadata);
            }

            if (folder.DocumentCount > 0)
            {
                context.RecommendedCapabilities.Add(
                    CapabilityNames.OrganizeDocuments);
            }

            if (folder.FileCount > 500)
            {
                context.RecommendedCapabilities.Add(
                    CapabilityNames.DetectDuplicates);
            }
        }
    }
}