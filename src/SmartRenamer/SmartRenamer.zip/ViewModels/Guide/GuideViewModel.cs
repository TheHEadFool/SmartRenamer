﻿using SmartRenamer.Guide;
using SmartRenamer.Guide.Conversations;
using SmartRenamer.Guide.Models;
using SmartRenamer.Infrastructure;
using SmartRenamer.Models.Settings;

namespace SmartRenamer.ViewModels.Guide
{
    /// <summary>
    /// Coordinates the current conversation between the user
    /// and Guide. Individual conversations are implemented as
    /// ConversationTopic classes.
    /// </summary>
    public class GuideViewModel : ObservableObject
    {
        private readonly UserProfile profile = new();

        private ConversationTopic currentTopic;

        public GuideConversation Conversation { get; } = new();

        private string userInput = "";

        public string UserInput
        {
            get => userInput;
            set => SetProperty(ref userInput, value);
        }

        public RelayCommand SendCommand { get; }

        public RelayCommand ChooseFolderCommand { get; }

        public GuideViewModel()
        {
            SendCommand = new RelayCommand(Send);

            ChooseFolderCommand = new RelayCommand(ChooseFolder);

            //---------------------------------------------------
            // Start the first conversation
            //---------------------------------------------------

            currentTopic = new WelcomeTopic(profile);

            foreach (GuideMessage message in currentTopic.Begin())
            {
                Conversation.AddMessage(message);
            }
        }

        /// <summary>
        /// Handles user responses.
        /// </summary>
        private void Send()
        {
            if (string.IsNullOrWhiteSpace(UserInput))
                return;

            Conversation.AddUserMessage(UserInput);

            foreach (GuideMessage message in currentTopic.Continue(UserInput))
            {
                Conversation.AddMessage(message);
            }

            UserInput = "";
        }

        /// <summary>
        /// Temporary placeholder.
        /// The folder workflow will become its own
        /// ConversationTopic in the next step.
        /// </summary>
        private void ChooseFolder()
        {
            Conversation.AddGuideMessage(
                "Folder selection will be connected to the new conversation engine in the next step.");
        }
    }
}